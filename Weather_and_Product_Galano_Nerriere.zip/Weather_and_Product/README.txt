Hello,

Project IT Tools for Big Data

Victoria Galano - Pauline Nerriere


#########################################
#########################################
#########################################
FOR THE CUSTOMER PROJECT:

#######
customer_product folder contains:
- Folder about datasets (normally you have it)
- programs:
	1-loadTables    		a hive program to load the HDFS dataset to hive
	2-allProcess(oozieJSON).json	a oozie launcher of hive programs
	oozie_*				hql Hive programs to have in the HDFS
	z_brouillon_*			the process1 and process2 with steps and comments while doing it
#######
TO DO :

put the datasets in hdfs (you have it, not put in github)
put the oozie_* in hdfs
put the json file in oozie
change the url in 1-loadTables for the datasets  (/user/cloudera/... for your own place folder)
Launch 1-loadTables
Launch the oozie allProcess(oozieJSON).json


#########################################
#########################################
#########################################

FOR THE WEATHER PROJECT:

#######
weather folder contains:
	- forecast_dpt_France.ipynb	a python notebook program
	- pref_ok			a modified CSV file having prefectures and lat;long
#######
TO DO :

follow the instructions written in the python script
(download forecastio, create a key, launch the script to initialize variables, see how it works, get the info for the 01-02-03 November)


#########################################
#########################################
#########################################
any questions? Send us a mail on your ensai mailbox